using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using Model;
using Data;
using VContainer;
using VContainer.Unity;
// Validation instrumentation in the isolated public demo, not a historical contribution.
 public class PortfolioProbe : MonoBehaviour {
 [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install(){new GameObject("Portfolio verification").AddComponent<PortfolioProbe>();}
 [Serializable] public class Snapshot {public int seed,width,height,level,hp;public bool key;public string mode,status;public int[] tiles,revealed,start,exit,keyTile;public int[] route; public float seconds;}
 [Serializable] public class MapMarkers {public float[] start,exit,key;public string note="Viewport positions from the actual overview camera; visual fog disabled only for this render.";}
 IEnumerator Start(){
  yield return new WaitForSeconds(2);
  var args=Environment.GetCommandLineArgs();
  string output=null,mode="efficient";
  for(int i=0;i<args.Length-1;i++){if(args[i]=="--portfolio-output")output=args[i+1];if(args[i]=="--portfolio-mode")mode=args[i+1];}
  if(output==null)yield break;
  Directory.CreateDirectory(output);
  var scope=FindFirstObjectByType<GameLifetimeScope>();
  var grid=scope.Container.Resolve<MapGrid>();var player=scope.Container.Resolve<Player>();
  var fog=scope.Container.Resolve<FogOfWar>();var room=scope.Container.Resolve<RoomManager>();var exit=scope.Container.Resolve<ExitDoor>();var config=scope.Container.Resolve<MapConfig>();
  var ai=scope.Container.Resolve<GoalAI>();var traversal=scope.Container.Resolve<MapTraversal>();var runner=scope.Container.Resolve<MapGeneratorRunner>();
  var snap=new Snapshot{seed=config.seed,width=grid.Width,height=grid.Height,level=1,hp=player.Health,mode=mode,start=new[]{player.X,player.Y},exit=new[]{exit.ExitX,exit.ExitY},keyTile=room.ActiveKeys.Count>0?new[]{room.ActiveKeys[0].TileX,room.ActiveKeys[0].TileY}:new[]{-1,-1},tiles=new int[grid.Width*grid.Height],revealed=new int[grid.Width*grid.Height]};
  for(int y=0;y<grid.Height;y++)for(int x=0;x<grid.Width;x++){snap.tiles[y*grid.Width+x]=(int)grid.GetTileType(x,y);snap.revealed[y*grid.Width+x]=fog.IsRevealed(x,y)?1:0;}
  File.WriteAllText(Path.Combine(output,"initial-"+mode+".json"),JsonUtility.ToJson(snap,true));
  if(SystemInfo.graphicsDeviceType!=UnityEngine.Rendering.GraphicsDeviceType.Null) {
   Capture(Path.Combine(output,"gameplay-"+mode+".png"));
   CaptureOverview(Path.Combine(output,"map-overview-"+mode+".png"),grid,fog);
  }
  var route=new List<int>(); player.OnMoved+=(x,y)=>{route.Add(x);route.Add(y);};
  if(mode=="traversal")traversal.Begin();else ai.Start(mode!="omniscient",mode=="efficient");
  var begin=Time.realtimeSinceStartup;
  while(Time.realtimeSinceStartup-begin<90f){
   yield return null;
   int level=(int)typeof(MapGeneratorRunner).GetField("_level",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(runner);
   if(level>1){snap.status="level-cleared";break;}
   if(player.IsDead){snap.status="death";break;}
   if(!ai.IsRunning&&!traversal.IsAutoWalking){snap.status="stopped";break;}
  }
  snap.route=route.ToArray(); snap.seconds=Time.realtimeSinceStartup-begin;snap.hp=player.Health;snap.key=player.HasKey;
  if(snap.status==null)snap.status="90-second-timeout";
  File.WriteAllText(Path.Combine(output,"run-"+mode+".json"),JsonUtility.ToJson(snap,true));
  Debug.Log("PORTFOLIO_PROBE "+snap.status+" steps="+(snap.route.Length/2)+" seconds="+snap.seconds);
  Application.Quit();
 }
 void Capture(string path){
  var cam=Camera.main; if(cam==null)return;
  var rt=RenderTexture.GetTemporary(1280,800,24);
  UnityEngine.Rendering.RenderPipeline.SubmitRenderRequest(cam,new UnityEngine.Rendering.Universal.UniversalRenderPipeline.SingleCameraRequest{destination=rt});
  var previous=RenderTexture.active;RenderTexture.active=rt;
  var image=new Texture2D(1280,800,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,1280,800),0,0);image.Apply();
  File.WriteAllBytes(path,image.EncodeToPNG());Destroy(image);RenderTexture.active=previous;RenderTexture.ReleaseTemporary(rt);
 }
 void CaptureOverview(string path, MapGrid grid, FogOfWar fog){
  var cam=Camera.main; if(cam==null)return;
  var tilemap=FindFirstObjectByType<UnityEngine.Tilemaps.Tilemap>();
  var lower=tilemap.CellToWorld(Vector3Int.zero);
  var upper=tilemap.CellToWorld(new Vector3Int(grid.Width,grid.Height,0));
  var savedPosition=cam.transform.position;var savedSize=cam.orthographicSize;var savedAspect=cam.aspect;
  var renderer=(SpriteRenderer)typeof(FogOfWar).GetField("_fogRenderer",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(fog);
  var wasEnabled=renderer!=null&&renderer.enabled;
  var rt=RenderTexture.GetTemporary(1600,1600,24);
  var previous=RenderTexture.active;
  try {
   cam.transform.position=new Vector3((lower.x+upper.x)/2,(lower.y+upper.y)/2,savedPosition.z);
   cam.orthographicSize=Mathf.Max(Mathf.Abs(upper.x-lower.x),Mathf.Abs(upper.y-lower.y))/2+0.3f;cam.aspect=1;
   if(renderer!=null)renderer.enabled=false;
   UnityEngine.Rendering.RenderPipeline.SubmitRenderRequest(cam,new UnityEngine.Rendering.Universal.UniversalRenderPipeline.SingleCameraRequest{destination=rt});
   RenderTexture.active=rt;
   var image=new Texture2D(1600,1600,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,1600,1600),0,0);image.Apply();
   File.WriteAllBytes(path,image.EncodeToPNG());Destroy(image);
   var scope=FindFirstObjectByType<GameLifetimeScope>();
   var player=scope.Container.Resolve<Player>();var exit=scope.Container.Resolve<ExitDoor>();var room=scope.Container.Resolve<RoomManager>();
   var markers=new MapMarkers {start=MapPoint(cam,tilemap,player.X,player.Y),exit=MapPoint(cam,tilemap,exit.ExitX,exit.ExitY),key=room.ActiveKeys.Count>0?MapPoint(cam,tilemap,room.ActiveKeys[0].TileX,room.ActiveKeys[0].TileY):new float[]{-1,-1}};
   File.WriteAllText(path+".markers.json",JsonUtility.ToJson(markers,true));
  } finally {
   cam.transform.position=savedPosition;cam.orthographicSize=savedSize;cam.aspect=savedAspect;
   if(renderer!=null)renderer.enabled=wasEnabled;
   RenderTexture.active=previous;RenderTexture.ReleaseTemporary(rt);
  }
 }
 float[] MapPoint(Camera cam,UnityEngine.Tilemaps.Tilemap tilemap,int x,int y){
  var point=cam.WorldToViewportPoint(tilemap.CellToWorld(new Vector3Int(x,y,0))+tilemap.cellSize*0.5f);
  return new float[]{point.x,1-point.y};
 }
 void OnGUI(){GUI.Label(new Rect(14,14,650,26),"ProjectMG | Portfolio Review Edition | Original artwork restored with permission");}
}

