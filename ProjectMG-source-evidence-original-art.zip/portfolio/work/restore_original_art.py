from pathlib import Path
import shutil, hashlib, json
root=Path(__file__).resolve().parents[2]
demo=root/'portfolio/work/UnityDemo'
audit=[]
for original in (root/'Assets').rglob('*'):
    if original.suffix.lower() not in {'.png','.jpg','.jpeg'}: continue
    relative=original.relative_to(root)
    restored=demo/relative
    shutil.copy2(original,restored)
    digest=hashlib.sha256(original.read_bytes()).hexdigest()
    assert hashlib.sha256(restored.read_bytes()).hexdigest()==digest
    audit.append({'path':relative.as_posix(),'sha256':digest,'status':'original pixels restored'})
for name,relative in [('PortfolioProbe.cs','Assets/Scripts/PortfolioProbe.cs'),('PortfolioBuild.cs','Assets/Editor/PortfolioBuild.cs')]:
    shutil.copy2(root/'portfolio/work'/name,demo/relative)
record={'authorization':'User confirmed public display and binary redistribution permission on 2026-09-13. Original copyright ownership retained.','assets':audit}
(root/'portfolio/work/art-restoration.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(f'Restored and verified {len(audit)} original raster files in isolated demo. Original Unity project untouched.')
