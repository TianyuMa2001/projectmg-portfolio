using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using Model;
using Data;
using VContainer;
using VContainer.Unity;
// Validation instrumentation in the isolated public demo, not a historical contribution.
public class PortfolioProbe : MonoBehaviour {
 [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install(){new GameObject("Portfolio verification").AddComponent<PortfolioProbe>();}
 [Serializable] public class Snapshot {public int seed,width,height,level,hp;public bool key;public string mode,status;public int[] tiles,revealed,start,exit,keyTile;public int[] route; public float seconds;}
 IEnumerator Start(){
  yield return new WaitForSeconds(2);
  var args=Environment.GetCommandLineArgs();
  string output=null,mode="efficient";
  for(int i=0;i<args.Length-1;i++){if(args[i]=="--portfolio-output")output=args[i+1];if(args[i]=="--portfolio-mode")mode=args[i+1];}
  if(output==null)yield break;
  Directory.CreateDirectory(output);
  var scope=FindFirstObjectByType<GameLifetimeScope>();
  var grid=scope.Container.Resolve<MapGrid>();var player=scope.Container.Resolve<Player>();
  var fog=scope.Container.Resolve<FogOfWar>();var room=scope.Container.Resolve<RoomManager>();var exit=scope.Container.Resolve<ExitDoor>();var config=scope.Container.Resolve<MapConfig>();
  var ai=scope.Container.Resolve<GoalAI>();var traversal=scope.Container.Resolve<MapTraversal>();var runner=scope.Container.Resolve<MapGeneratorRunner>();
  var snap=new Snapshot{seed=config.seed,width=grid.Width,height=grid.Height,level=1,hp=player.Health,mode=mode,start=new[]{player.X,player.Y},exit=new[]{exit.ExitX,exit.ExitY},keyTile=room.ActiveKeys.Count>0?new[]{room.ActiveKeys[0].TileX,room.ActiveKeys[0].TileY}:new[]{-1,-1},tiles=new int[grid.Width*grid.Height],revealed=new int[grid.Width*grid.Height]};
  for(int y=0;y<grid.Height;y++)for(int x=0;x<grid.Width;x++){snap.tiles[y*grid.Width+x]=(int)grid.GetTileType(x,y);snap.revealed[y*grid.Width+x]=fog.IsRevealed(x,y)?1:0;}
  File.WriteAllText(Path.Combine(output,"initial-"+mode+".json"),JsonUtility.ToJson(snap,true));
  if(SystemInfo.graphicsDeviceType!=UnityEngine.Rendering.GraphicsDeviceType.Null) Capture(Path.Combine(output,"gameplay-"+mode+".png"));
  var route=new List<int>(); player.OnMoved+=(x,y)=>{route.Add(x);route.Add(y);};
  if(mode=="traversal")traversal.Begin();else ai.Start(mode!="omniscient",mode=="efficient");
  var begin=Time.realtimeSinceStartup;
  while(Time.realtimeSinceStartup-begin<90f){
   yield return null;
   int level=(int)typeof(MapGeneratorRunner).GetField("_level",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(runner);
   if(level>1){snap.status="level-cleared";break;}
   if(player.IsDead){snap.status="death";break;}
   if(!ai.IsRunning&&!traversal.IsAutoWalking){snap.status="stopped";break;}
  }
  snap.route=route.ToArray(); snap.seconds=Time.realtimeSinceStartup-begin;snap.hp=player.Health;snap.key=player.HasKey;
  if(snap.status==null)snap.status="90-second-timeout";
  File.WriteAllText(Path.Combine(output,"run-"+mode+".json"),JsonUtility.ToJson(snap,true));
  Debug.Log("PORTFOLIO_PROBE "+snap.status+" steps="+(snap.route.Length/2)+" seconds="+snap.seconds);
  Application.Quit();
 }
 void Capture(string path){
  var cam=Camera.main; if(cam==null)return;
  var rt=RenderTexture.GetTemporary(1280,800,24);
  UnityEngine.Rendering.RenderPipeline.SubmitRenderRequest(cam,new UnityEngine.Rendering.Universal.UniversalRenderPipeline.SingleCameraRequest{destination=rt});
  var previous=RenderTexture.active;RenderTexture.active=rt;
  var image=new Texture2D(1280,800,TextureFormat.RGB24,false);image.ReadPixels(new Rect(0,0,1280,800),0,0);image.Apply();
  File.WriteAllBytes(path,image.EncodeToPNG());Destroy(image);RenderTexture.active=previous;RenderTexture.ReleaseTemporary(rt);
 }
 void OnGUI(){GUI.Label(new Rect(14,14,650,26),"ProjectMG | Portfolio Debug Edition | Original abstract replacement visuals");}
}

