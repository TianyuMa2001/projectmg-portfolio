using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using System.IO;
public static class PortfolioBuild {
 public static void Build() {
  PlayerSettings.productName="ProjectMG - Portfolio Debug Edition";
  PlayerSettings.companyName="HachimiGame";
  PlayerSettings.defaultIsFullScreen=false; PlayerSettings.runInBackground=true;
  PlayerSettings.defaultScreenWidth=1280; PlayerSettings.defaultScreenHeight=800;
  PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Standalone,ScriptingImplementation.Mono2x);
  var dir=Path.GetFullPath(Path.Combine(Application.dataPath,"../../../../deliverables/ProjectMG-Windows"));
  Directory.CreateDirectory(dir);
  var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes=new[]{"Assets/Scenes/SampleScene.unity"}, locationPathName=Path.Combine(dir,"ProjectMG.exe"),target=BuildTarget.StandaloneWindows64,options=BuildOptions.Development });
  if(report.summary.result!=BuildResult.Succeeded) throw new System.Exception("Portfolio build failed: "+report.summary.result);
  Debug.Log("PORTFOLIO_BUILD_SUCCESS "+dir);
 }
}

