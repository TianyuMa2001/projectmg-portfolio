using System.Reflection;
using System.Text.Json;
using Data;using Model;using UnityEngine;using Generators;
var output=Path.GetFullPath(args.Length>0?args[0]:"../../evidence-output");Directory.CreateDirectory(output);
object Call(object instance,string name,params object[] args)=>instance.GetType().GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(instance,args);
void Set(object instance,string name,object value)=>instance.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).SetValue(instance,value);
int[][] XY(List<(int x,int y)> p)=>p.Select(v=>new[]{v.x,v.y}).ToArray();
var config=new MapConfig{width=22,height=14};var grid=new MapGrid(config,new TileRegistry());grid.Reset(TileType.Wall);
// Fixed two-route fixture: short hazardous route across y=4, longer safe route across y=10.
for(int x=2;x<=19;x++){grid.Set(x,4,TileType.Floor);grid.Set(x,10,TileType.Floor);}
for(int y=4;y<=10;y++){grid.Set(2,y,TileType.Floor);grid.Set(19,y,TileType.Floor);}
var player=new Player();player.TeleportTo(2,4);var room=new RoomManager();room.LiveMonsters.Add(new MonsterEntity{TileX=10,TileY=4});
room.ActiveChests.Add(new Chest{TileX=2,TileY=10});var fog=new FogOfWar{cells=new bool[22,14]};for(int x=0;x<22;x++)for(int y=0;y<14;y++)fog.cells[x,y]=true;
var traversal=new MapTraversal(grid,player,fog,room,new ExitDoor{ExitX=19,ExitY=4});
var rows=new List<object>();
foreach(float multiplier in new[]{0f,1f}){
 Call(traversal,"BuildDangerMap");var danger=(float[,])typeof(MapTraversal).GetField("_dangerMap",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(traversal);
 for(int x=0;x<22;x++)for(int y=0;y<14;y++)danger[x,y]*=multiplier;
 var path=(List<(int x,int y)>)Call(traversal,"FindPath",2,4,19,4,true);
 if(path.Count==0)throw new Exception("Missing fixture route");
 int exposure=path.Count(p=>Math.Max(Math.Abs(p.x-10),Math.Abs(p.y-4))<=3);
 rows.Add(new{multiplier,steps=path.Count-1,dangerZoneTiles=exposure,path=XY(path)});
}
// Execute real chest eligibility code, without simulating healing or combat.
player.TakeDamage(36);var chest=Call(traversal,"FindChestDetour");if(chest==null)throw new Exception("Expected 64% HP chest detour");
player.ResetHealth();player.TakeDamage(35);var noChest=Call(traversal,"FindChestDetour");if(noChest!=null)throw new Exception("65% HP should not detour");
// Fog-aware A*: a hidden intermediate blocks the only available route, then reopening it permits the route.
fog.cells[2,7]=false;fog.cells[10,4]=false;
var blocked=(List<(int x,int y)>)Call(traversal,"FindPath",2,4,19,4,true);
var omniscient=(List<(int x,int y)>)Call(traversal,"FindPath",2,4,19,4,false);
if(blocked.Count!=0||omniscient.Count==0)throw new Exception("Fog route gate failed");
var tiles=Enumerable.Range(0,14).SelectMany(y=>Enumerable.Range(0,22).Select(x=>(int)grid.GetTileType(x,y))).ToArray();
File.WriteAllText(Path.Combine(output,"routing-experiment.json"),JsonSerializer.Serialize(new{sourceCommit="6ed95c1",fixture="two-route-22x14-v1",method="Actual unmodified MapTraversal.FindPath; all revealed; scale computed danger map by 0 or 1. No gameplay timing, combat or Unity rendering.",start=new[]{2,4},exit=new[]{19,4},monster=new[]{10,4},chest=new[]{2,10},width=22,height=14,tiles,results=rows,checks=new{chestAt64Percent=true,noChestAt65Percent=true,hiddenIntermediateBlocks=true,unconstrainedRouteExists=true}},new JsonSerializerOptions{WriteIndented=true}));
var generatedConfig=new MapConfig();var generatedGrid=new MapGrid(generatedConfig,new TileRegistry());var generator=new DelaunayKruskalGenerator();generator.Generate(generatedGrid,generatedConfig);
var start=generator.GetStartPosition(generatedGrid);var generatedTiles=Enumerable.Range(0,64).SelectMany(y=>Enumerable.Range(0,64).Select(x=>(int)generatedGrid.GetTileType(x,y))).ToArray();
var accessible=new HashSet<(int,int)>{(start.x,start.y)};var queue=new Queue<(int,int)>();queue.Enqueue((start.x,start.y));while(queue.Count>0){var p=queue.Dequeue();foreach(var d in new[]{(1,0),(-1,0),(0,1),(0,-1)}){var n=(p.Item1+d.Item1,p.Item2+d.Item2);if(generatedGrid.InBounds(n.Item1,n.Item2)&&generatedGrid.GetTileType(n.Item1,n.Item2)!=TileType.Wall&&accessible.Add(n))queue.Enqueue(n);}}
int walkable=generatedTiles.Count(t=>t!=(int)TileType.Wall);if(accessible.Count!=walkable)throw new Exception("Generated map disconnected");
File.WriteAllText(Path.Combine(output,"generator-snapshot.json"),JsonSerializer.Serialize(new{seed=5800,adapter="System.Random, not UnityEngine.Random; not a screenshot and not a Unity seed reproduction",width=64,height=64,start=new[]{start.x,start.y},walkable,reachable=accessible.Count,tiles=generatedTiles}));
Console.WriteLine("PASS: routing, chest thresholds, fog route gate; generator connectivity. Evidence saved.");
var movement=new List<object>();
foreach(var test in new[]{("open-diagonal",true,true,true,3,3),("horizontal-fallback",true,false,true,3,2),("vertical-fallback",false,true,true,2,3),("closed-corner",false,false,true,2,2),("diagonal-wall-horizontal-priority",true,true,false,3,2)}){
 var g=new MapGrid(new MapConfig{width=6,height=6},new TileRegistry());g.Reset(TileType.Floor);g.Set(3,2,test.Item2?TileType.Floor:TileType.Wall);g.Set(2,3,test.Item3?TileType.Floor:TileType.Wall);g.Set(3,3,test.Item4?TileType.Floor:TileType.Wall);
 var p=new Player();p.TeleportTo(2,2);var input=new PlayerInput();input.Player.Move.value=new Vector2(1,1);
 var controller=new PlayerController(p,g,input,new PlayerView(),new MapTraversal(g,p,new FogOfWar{cells=new bool[6,6]},new RoomManager(),new ExitDoor()),new GoalAI());controller.Tick();
 if(p.X!=test.Item5||p.Y!=test.Item6)throw new Exception("Movement regression: "+test.Item1);
 movement.Add(new{name=test.Item1,result="pass",actual=new[]{p.X,p.Y}});controller.Dispose();
}
File.WriteAllText(Path.Combine(output,"movement-checks.json"),JsonSerializer.Serialize(movement,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine("PASS: five checks execute actual PlayerController.Tick. Visual timing not measured.");
