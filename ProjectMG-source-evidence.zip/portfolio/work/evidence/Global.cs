global using Random = UnityEngine.Random;
