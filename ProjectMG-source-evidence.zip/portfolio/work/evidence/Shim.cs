using System;
using System.Collections.Generic;
namespace UnityEngine {
 public class ScriptableObject {}
 public class CreateAssetMenuAttribute:Attribute {public string fileName,menuName;}
 public struct Vector2Int {public int x,y;public Vector2Int(int x,int y){this.x=x;this.y=y;}public static float Distance(Vector2Int a,Vector2Int b)=>(float)Math.Sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));}
 public struct Vector2 {public float x,y;public Vector2(float x,float y){this.x=x;this.y=y;}public static Vector2 zero=>new(0,0);public static bool operator ==(Vector2 a,Vector2 b)=>a.x==b.x&&a.y==b.y;public static bool operator !=(Vector2 a,Vector2 b)=>!(a==b);public override bool Equals(object o)=>o is Vector2 v&&this==v;public override int GetHashCode()=>HashCode.Combine(x,y);}
 public struct RectInt {public int x,y,width,height;public RectInt(int x,int y,int w,int h){this.x=x;this.y=y;width=w;height=h;}public bool Overlaps(RectInt b)=>x<b.x+b.width&&x+width>b.x&&y<b.y+b.height&&y+height>b.y;}
 public static class Mathf {public static int Abs(int a)=>Math.Abs(a);public static float Abs(float a)=>Math.Abs(a);public static int Max(int a,int b)=>Math.Max(a,b);public static float Max(float a,float b)=>Math.Max(a,b);public static int Min(int a,int b)=>Math.Min(a,b);public static float Min(float a,float b)=>Math.Min(a,b);public static int RoundToInt(float a)=>(int)Math.Round(a);}
 // Explicitly NOT Unity's PRNG. Only the headless generator diagram uses this adapter.
 public static class Random {static System.Random rng=new(5800);public static void InitState(int s){rng=new(s);}public static int Range(int a,int b)=>rng.Next(a,b);}
 public static class Time {public static float deltaTime=0.12f;}
 public static class Debug {public static void Log(object x){}public static void LogWarning(object x){} }
}
namespace UnityEngine.Tilemaps {public class TileBase {}}
namespace UnityEngine.InputSystem {public enum Key {T}public class Keyboard {public static Keyboard current=>null;public Button this[Key k]=>new();}public class Button {public bool wasPressedThisFrame=>false;}}
namespace VContainer.Unity {public interface ITickable {void Tick();}}
public class MapConfig {public int width=64,height=64,seed=5800;}
public class TileRegistry {public UnityEngine.Tilemaps.TileBase Get(Data.TileType t)=>null;}
public class FogOfWar {public bool[,] cells;public bool IsRevealed(int x,int y)=>cells[x,y];}
public class MonsterEntity {public int TileX,TileY;public bool IsActive=true;}
public class Chest {public int TileX,TileY;public bool IsActive=true;}
public class KeyItem {public int TileX,TileY;public bool IsActive=true;}
public class RoomManager {public List<MonsterEntity> LiveMonsters=new();public List<Chest> ActiveChests=new();public List<KeyItem> ActiveKeys=new();}
public class ExitDoor {public int ExitX,ExitY;public bool IsPlaced=true;}
public class GoalAI {public bool IsRunning=>false;}
public class PlayerView {public bool IsAnimating=>false;}
public class PlayerInput:System.IDisposable {public Actions Player=new(),UI=new();public class Actions {public MoveAction Move=new();public void Enable(){}public void Disable(){}}public class MoveAction {public UnityEngine.Vector2 value;public T ReadValue<T>()=>(T)(object)value;}public void Dispose(){}}
