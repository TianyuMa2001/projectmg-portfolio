from pathlib import Path
import shutil, re, json
from PIL import Image, ImageDraw
root=Path(__file__).resolve().parents[2]
dest=root/'portfolio/work/UnityDemo'
dest.mkdir(exist_ok=True)
for name in ['Assets','Packages','ProjectSettings']:
    shutil.copytree(root/name,dest/name,dirs_exist_ok=True)
manifest=[]
for p in (dest/'Assets').rglob('*'):
    if p.suffix.lower() not in ['.png','.jpg','.jpeg']: continue
    with Image.open(p) as src: size=src.size
    # Original abstract debug swatches, never a copy of the team's artwork.
    name=p.name.lower()
    color=(64,211,195,255) if ('idle' in name or 'walk' in name or 'alia' in name) else (59,74,95,255) if 'wall' in name else (133,109,255,255) if 'poison' in name else (224,190,91,255) if ('coin' in name or 'chest' in name or 'key' in name) else (124,150,170,255)
    im=Image.new('RGBA',size,color)
    draw=ImageDraw.Draw(im)
    for x in range(0,size[0],32): draw.line((x,0,x,size[1]),fill=(20,29,44,255))
    for y in range(0,size[1],32): draw.line((0,y,size[0],y),fill=(20,29,44,255))
    if p.suffix.lower() in ['.jpg','.jpeg']: im=im.convert('RGB')
    im.save(p)
    manifest.append({'path':str(p.relative_to(dest)).replace('\\','/'),'size':size,'replacement':'original abstract debug swatch'})
scene=dest/'Assets/Scenes/SampleScene.unity'
scene.write_text(scene.read_text(encoding='utf-8-sig').replace('animateGeneration: 1','animateGeneration: 0'),encoding='utf-8')
config=dest/'Assets/Configs/MapConfig.asset'
config.write_text(config.read_text().replace('randomSeed: 1','randomSeed: 0').replace('seed: 251886795','seed: 5800'))
(root/'portfolio/work/art-replacements.json').write_text(json.dumps(manifest,indent=2))
shutil.copy(root/'portfolio/work/PortfolioBuild.cs',dest/'Assets/Editor/PortfolioBuild.cs')
shutil.copy(root/'portfolio/work/PortfolioProbe.cs',dest/'Assets/Scripts/PortfolioProbe.cs')
print(f'Isolated demo prepared; {len(manifest)} raster assets replaced; original project unchanged.')
